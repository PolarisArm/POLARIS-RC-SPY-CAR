getting_started.py
==================

.. literalinclude:: ../../../../examples_linux/getting_started.py
    :language: python
    :caption: examples_linux/getting_started.py
    :linenos:
    :lineno-match:
